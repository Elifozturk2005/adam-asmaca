<script>
const kelimeler = ["kedi", "oje", "muz", "bilgisayar", "çanta"];
let secilenKelime = "";
let tahminler = [];
let kalanHak = 6;

const wordEl = document.getElementById("word");
const triesEl = document.getElementById("tries");
const messageEl = document.getElementById("message");
const lettersEl = document.getElementById("letters");

function rastgeleKelime() {
    const index = Math.floor(Math.random() * kelimeler.length);
    return kelimeler[index];
}

function guncelleEkran() {
    let gosterim = "";
    for (let harf of secilenKelime) {
        if (tahminler.includes(harf)) {
            gosterim += harf + " ";
        } else {
            gosterim += "_ ";
        }
    }

    wordEl.textContent = gosterim.trim();

    if (!gosterim.includes("_")) {
        messageEl.textContent = "🎉 Tebrikler, kazandın!";
        kilitle();
    }

    if (kalanHak === 0) {
        messageEl.textContent = "😞 Kaybettin! Kelime: " + secilenKelime;
        kilitle();
    }

    triesEl.textContent = kalanHak;
}

function harfTikla(harf) {
    if (tahminler.includes(harf) || kalanHak === 0) return;

    tahminler.push(harf);

    if (!secilenKelime.includes(harf)) {
        kalanHak--;
    }

    guncelleEkran();
}

function kilitle() {
    const tuslar = document.querySelectorAll("#letters button");
    tuslar.forEach(b => b.disabled = true);
}

function restartGame() {
    secilenKelime = rastgeleKelime();
    tahminler = [];
    kalanHak = 6;
    messageEl.textContent = "";
    guncelleEkran();
    olusturHarfButonlari();
}

function olusturHarfButonlari() {
    lettersEl.innerHTML = "";
    const alfabe = "abcçdefgğhıijklmnoöprsştuüvyz";
    for (let harf of alfabe) {
        const buton = document.createElement("button");
        buton.textContent = harf;
        buton.onclick = () => harfTikla(harf);
        lettersEl.appendChild(buton);
    }
}

restartGame();
</script>
